package com.student.repository;

public interface Student {

}
