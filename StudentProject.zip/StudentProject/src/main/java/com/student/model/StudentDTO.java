package com.student.model;

import lombok.Data;


@Data
public class StudentDTO {
	
	private int id;
	private String stu_name;
	private long stu_phone;
	private String stu_email;

}
